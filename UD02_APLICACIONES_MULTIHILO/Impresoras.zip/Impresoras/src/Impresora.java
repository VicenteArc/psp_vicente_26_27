
public class Impresora implements Runnable {

    // Campos de la impresora
    private String nombre;
    private int numeroPaginas;

    // Constructor que recibe el nombre y el número de páginas
    public Impresora(String nombre, int numeroPaginas) {
        this.nombre = nombre;
        this.numeroPaginas = numeroPaginas;
    }

    @Override
    public void run() {

        // Recorre todas las páginas que tiene que imprimir
        for (int i = 1; i <= numeroPaginas; i++) {

            System.out.println(nombre + " - Imprimiendo página "+i+" de "+numeroPaginas);

            try {
                // Simula el tiempo que tarda en imprimir una página
                Thread.sleep(1000);

            } catch (InterruptedException e) {

                // Restablece el estado de interrupción del hilo
                Thread.currentThread().interrupt();

                // Termina la tarea si el hilo ha sido interrumpido
                return;
            }
        }

        // Mensaje cuando termina de imprimir todas las páginas
        System.out.println(nombre+" - Impresión finalizada");
    }
}
