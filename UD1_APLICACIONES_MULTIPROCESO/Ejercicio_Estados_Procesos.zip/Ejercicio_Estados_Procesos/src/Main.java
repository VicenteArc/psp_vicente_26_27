import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

    public static void main(String[] args) {

        // Creamos el proceso que ejecutará ping
        ProcessBuilder processBuilder = new ProcessBuilder("ping", "-c", "4", "localhost");

        Process process = null;

        try {
            // Iniciamos el proceso.
            process = processBuilder.start();

            // Comprobamos si el proceso está vivo.
            System.out.println("Está vivo: "+process.isAlive());

            // Mostramos la información del proceso.
            System.out.println("Información del proceso");
            System.out.println("PID: "+process.pid());
            System.out.println("Comando: "+ process.info().command().orElse("No disponible"));
            System.out.println("Argumentos: " + process.info().arguments()
                            .map(argsArray -> String.join(" ", argsArray))
                            .orElse("No disponibles"));
            System.out.println("Usuario: "+ process.info().user().orElse("No disponible"));

            // Creamos los lectores de salida estándar y errores.
            BufferedReader stdOut = new BufferedReader(
                    new InputStreamReader(process.getInputStream()));

            BufferedReader stdErr = new BufferedReader(
                    new InputStreamReader(process.getErrorStream()));

            // Mostramos la salida del proceso.
            System.out.println("Salida estándar");
            stdOut.lines().forEach(System.out::println);

            System.out.println("Errores");
            stdErr.lines().forEach(System.out::println);

            // Esperamos a que el proceso finalice.
            int resultado = process.waitFor();

            // Mostramos el resultado final.
            System.out.println("Resultado final");
            System.out.println("Código de salida: "+resultado);
            System.out.println("Está vivo: "+process.isAlive());

        } catch (IOException e) {
            System.out.println("Error al ejecutar el proceso.");
            e.printStackTrace();

        } catch (InterruptedException e) {
            System.out.println("El proceso ha sido interrumpido.");
            Thread.currentThread().interrupt();

        } catch (SecurityException e) {
            System.out.println("No tienes permisos para ejecutar el proceso.");
            e.printStackTrace();
        }
    }
}
